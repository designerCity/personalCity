// 'use strict';

// /** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('Members', [
      {
        id: 1,
        name: 'Alex',
        team: 'engineering',
        position: 'Server Developer',
        emailAddress: 'alex@google.com',
        phoneNumber: '010-xxxx-xxxx',
        admissionDate: '2018/12/10',
        birthday: '1994/11/08',
        profileImage: 'profile1.png',
      },
      {
        id: 2,
        name: 'Benjamin',
        team: 'engineering',
        position: 'Server Developer',
        emailAddress: 'benjamin@google.com',
        phoneNumber: '010-xxxx-xxxx',
        admissionDate: '2021/01/20',
        birthday: '1992/03/26',
        profileImage: 'profile2.png',
      },
      {
        id: 3,
        name: 'Charles',
        team: 'engineering',
        position: 'Android Developer',
        emailAddress: 'charles@google.com',
        phoneNumber: '010-xxxx-xxxx',
        admissionDate: '2018/10/09',
        birthday: '1994/09/08',
        profileImage: 'profile3.png',
      },
      {
        id: 4,
        name: 'Eric',
        team: 'engineering',
        position: 'Web Frontend Developer',
        emailAddress: 'eric@google.com',
        phoneNumber: '010-xxxx-xxxx',
        admissionDate: '2020/04/07',
        birthday: '1995/04/10',
        profileImage: 'profile4.png',
      },
      {
        id: 5,
        name: 'Danial',
        team: 'marketing',
        position: 'Marketing Manager',
        emailAddress: 'danial@google.com',
        phoneNumber: '010-xxxx-xxxx',
        admissionDate: '2021/04/21',
        birthday: '1991/07/12',
        profileImage: 'profile5.png',
      },
      {
        id: 6,
        name: 'George',
        team: 'marketing',
        position: 'Marketing Staff',
        emailAddress: 'george@google.com',
        phoneNumber: '010-xxxx-xxxx',
        admissionDate: '2020/01/06',
        birthday: '1997/02/09',
        profileImage: 'profile6.png',
      },
      {
        id: 7,
        name: 'Henry',
        team: 'marketing',
        position: 'Marketing Staff',
        emailAddress: 'henry@google.com',
        phoneNumber: '010-xxxx-xxxx',
        admissionDate: '2020/04/03',
        birthday: '1997/08/18',
        profileImage: 'profile7.png',
      },
      {
        id: 8,
        name: 'James',
        team: 'sales',
        position: 'Sales Manager',
        emailAddress: 'james@google.com',
        phoneNumber: '010-xxxx-xxxx',
        admissionDate: '2020/11/26',
        birthday: '1993/05/22',
        profileImage: 'profile8.png',
      },
      {
        id: 9,
        name: 'Kevin',
        team: 'sales',
        position: 'Sales Staff',
        emailAddress: 'kevin@google.com',
        phoneNumber: '010-xxxx-xxxx',
        admissionDate: '2020/06/19',
        birthday: '1989/06/10',
        profileImage: 'profile9.png',
      },
      {
        id: 10,
        name: 'Michael',
        team: 'sales',
        position: 'Sales Staff',
        emailAddress: 'michael@google.com',
        phoneNumber: '010-xxxx-xxxx',
        admissionDate: '2019/11/12',
        birthday: '1992/09/17',
        profileImage: 'profile10.png',
      },
    ])
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('Members', null, {});
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
  }
};
